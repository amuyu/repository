plugins {
    id("gradlebuild.distribution.implementation-java")
    id("gradlebuild.api-metadata")
}
